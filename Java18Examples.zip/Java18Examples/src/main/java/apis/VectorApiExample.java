package apis;

import jdk.incubator.vector.IntVector;

/**
 * Beispielprogramm für die Workshops "Best of Java 11 - 17 / 18 / 19" und das 
 * Buch "Java – Die Neuerungen in Version 17 LTS, 18 und 19"
 *
 * @author Michael Inden
 *         <p>
 *         Copyright 2021/22 by Michael Inden
 */

//Für Eclipse RUN CONFIGURATION: --add-modules jdk.incubator.vector
//Ausführen auf Konsole java --add-modules jdk.incubator.vector VectorApiExample

public class VectorApiExample
{
    public static void main(final String[] args) 
    {
        final int[] a = {1, 2, 3, 4};
        final int[] b = {5, 6, 7, 8};
        var c = new int[a.length];

        var vectorA = IntVector.fromArray(IntVector.SPECIES_128, a, 0);
        var vectorB = IntVector.fromArray(IntVector.SPECIES_128, b, 0);
        var vectorC = vectorA.add(vectorB);
        // var vectorC = vectorA.mul(vectorB);
        vectorC.intoArray(c, 0);
        
        System.out.println(vectorC);
    }
}